//
//  BUInterfaceBaseObject.h
//  BUAdSDK
//
//  Created by zth on 2022/3/22.
//

/**
 接口层基类
 */
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BUInterfaceBaseObject : NSObject

@end

NS_ASSUME_NONNULL_END
