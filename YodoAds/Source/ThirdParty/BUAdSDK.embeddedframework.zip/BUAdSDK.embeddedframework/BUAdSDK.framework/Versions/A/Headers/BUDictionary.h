//
//  BUDictionary.h
//  BUAdSDK
//
//  Created by ByteDance on 2022/10/20.


#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BUDictionary : NSDictionary

@end

NS_ASSUME_NONNULL_END
