//
//  BUMPrivacyConfig.h
//  BUAdSDK
//
//  Created by 🦁 on 2022/12/16.
//

#import <Foundation/Foundation.h>

/// 【可选】NSNumber，是否限制个性化广告:0-不限制，1-限制，默认为0。官方维护版本中只适用于CSJ、Ks、Sigmob、百度、GDT。
const static NSString *kBUMPrivacyLimitPersonalAds = @"ABUPrivacyLimitPersonalAds";

/// 【可选】NSNumber，是否限制程序化广告:0-不限制，1-限制，默认为0。官方维护版本中只适用于Ks。
const static NSString *kBUMPrivacyLimitProgrammaticAds = @"ABUPrivacyLimitProgrammaticAds";

/// 【可选】NSNumber，是否禁止CAID：0-不禁止，1-禁止，默认为0。官方维护版本中只适用于百度。
const static NSString *kBUMPrivacyForbiddenCAID = @"ABUPrivacyForbiddenCAID";

/// 【可选】NSNumber，是否禁止IDFA：0-不禁止，1-禁止，默认为0。官方维护版本中只适用于GDT。
const static NSString *kBUMPrivacyForbiddenIDFA = @"ABUPrivacyForbiddenIDFA";

/// 【可选】NSNumber，是否在adn中使用位置，如果是，adn将自己获得纬度和经度，而不是使用传入的值（kBUMPrivacyLongitude/kBUMPrivacyLatitude）。官方维护版本中只适用于CSJ。
const static NSString *kBUMPrivacyCanLocation = @"ABUPrivacyCanLocation";

/// 【可选】NSNumber，经度的值。默认值是0.0。官方维护版本中只适用于CSJ。
const static NSString *kBUMPrivacyLongitude = @"ABUPrivacyLongitude";

/// 【可选】NSNumber，纬度的值。默认值是0.0。官方维护版本中只适用于CSJ。
const static NSString *kBUMPrivacyLatitude = @"ABUPrivacyLatitude";

/// 【可选】NSNumber，是成人或者儿童，2-儿童(＜15),1-儿童(15-18岁), 0-成人，默认为0(成人)。官方维护版本中适用于CSJ/sigmob。
const static NSString *kBUMPrivacyNotAdult = @"ABUPrivacyNotAdult";

