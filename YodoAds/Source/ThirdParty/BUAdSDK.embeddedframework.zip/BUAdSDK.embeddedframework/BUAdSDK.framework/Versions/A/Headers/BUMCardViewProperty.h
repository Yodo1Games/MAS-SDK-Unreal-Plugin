//
//  BUMCardViewProperty.h
//  BUAdSDK
//
//  Created by 🦁 on 2022/12/16.
//

#import "BUInterfaceBaseObject.h"

NS_ASSUME_NONNULL_BEGIN

@interface BUMCardViewProperty : BUInterfaceBaseObject

@end

NS_ASSUME_NONNULL_END
