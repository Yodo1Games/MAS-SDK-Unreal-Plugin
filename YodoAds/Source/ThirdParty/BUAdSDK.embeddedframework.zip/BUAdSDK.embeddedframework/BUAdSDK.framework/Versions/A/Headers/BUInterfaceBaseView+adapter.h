//
//  BUInterfaceBaseView+adapter.h
//  BUAdSDK
//
//  Created by zth on 2022/3/24.
//

#import "BUInterfaceBaseView.h"

NS_ASSUME_NONNULL_BEGIN

@interface BUInterfaceBaseView (adapter)

@end

NS_ASSUME_NONNULL_END
