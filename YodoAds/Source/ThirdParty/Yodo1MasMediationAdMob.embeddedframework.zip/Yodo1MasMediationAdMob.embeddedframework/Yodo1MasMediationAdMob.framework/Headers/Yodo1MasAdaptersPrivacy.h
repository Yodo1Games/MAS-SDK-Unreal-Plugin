//
//  Yodo1MasAdaptersPrivacy.h
//
//  Created by sunmeng on 2021/7/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasAdaptersPrivacy : NSObject

+ (void)setAdColonyPrivacy;
+ (void)setAppLovinPrivacy;
+ (void)setFyberPrivacy;
+ (void)setInMobiPrivacy;
+ (void)setIronSourcePrivacy;
+ (void)setFacebookPrivacy;
+ (void)setMintegralPrivacy;
+ (void)setPanglePrivacy;
+ (void)setTapjoyPrivacy;
+ (void)setUnityAdsPrivacy;
+ (void)setVunglePrivacy;

@end

NS_ASSUME_NONNULL_END
