//
//  Yodo1MasGoogleAdManagerRewardedInterstitialAdAdapter.h
//  Yodo1MasMediationAdMob
//
//  Created by 张永雪 on 2023/2/21.
//

#if __has_include(<Yodo1MasCore/Yodo1MasRewardedInterstitialAdAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasRewardedInterstitialAdAdapterBase.h>
#else
#import "Yodo1MasRewardedInterstitialAdAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasGoogleAdManagerRewardedInterstitialAdAdapter : Yodo1MasRewardedInterstitialAdAdapterBase

@property (nonatomic, assign) BOOL isMax;

@end

NS_ASSUME_NONNULL_END
