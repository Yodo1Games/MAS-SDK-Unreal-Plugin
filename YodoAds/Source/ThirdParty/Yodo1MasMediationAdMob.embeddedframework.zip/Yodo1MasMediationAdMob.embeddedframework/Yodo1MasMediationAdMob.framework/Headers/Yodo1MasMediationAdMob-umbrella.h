#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "Yodo1MasGoogleAdManagerAdapter.h"
#import "Yodo1MasGoogleAdManagerAppOpenAdAdapter.h"
#import "Yodo1MasGoogleAdManagerRewardedInterstitialAdAdapter.h"
#import "Yodo1MasAdMobAppOpenAdAdapter.h"
#import "Yodo1MasAdMobBannerAdapter.h"
#import "Yodo1MasAdMobInterstitialAdapter.h"
#import "Yodo1MasAdMobMaxAdapter.h"
#import "Yodo1MasAdMobRewardAdapter.h"
#import "Yodo1MasAdMobRewardedInterstitialAdAdapter.h"
#import "Yodo1MasAdaptersPrivacy.h"
#import "Yodo1MasAdMobAdapter.h"
#import "Yodo1MasAdMobUtils.h"

FOUNDATION_EXPORT double Yodo1MasMediationAdMobVersionNumber;
FOUNDATION_EXPORT const unsigned char Yodo1MasMediationAdMobVersionString[];

