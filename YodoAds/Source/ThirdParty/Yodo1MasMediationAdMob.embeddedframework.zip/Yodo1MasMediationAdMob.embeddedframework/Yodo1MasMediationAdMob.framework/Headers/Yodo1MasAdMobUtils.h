//
//  Yodo1MasAdMobUtils.h
//  Yodo1MasMediationAdMob
//
//  Created by Sunmeng on 2024/11/12.
//  Copyright © 2024 Yodo1 Games. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import "Yodo1MasAdAdapterBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasAdMobUtils : NSObject

+ (NSString*)getRevenuePrecision:(GADAdValuePrecision)precision;

+ (NSString*)getAdSourceName:(Yodo1MasAdAdapterBase*)adapter responseInfo:(GADAdNetworkResponseInfo*)responseInfo;
+ (NSString*)getAdSourceUnitId:(Yodo1MasAdAdapterBase*)adapter responseInfo:(GADAdNetworkResponseInfo*)responseInfo;

@end

NS_ASSUME_NONNULL_END
