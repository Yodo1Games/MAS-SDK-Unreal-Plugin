//
//  Yodo1MasAdMobRewardedInterstitialAdAdapter.h
//  Yodo1MasCore
//
//  Created by 周玉震 on 2022/9/26.
//

#if __has_include(<Yodo1MasCore/Yodo1MasRewardedInterstitialAdAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasRewardedInterstitialAdAdapterBase.h>
#else
#import "Yodo1MasRewardedInterstitialAdAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasAdMobRewardedInterstitialAdAdapter : Yodo1MasRewardedInterstitialAdAdapterBase

@property (nonatomic, assign) BOOL isMax;

@end

NS_ASSUME_NONNULL_END
