//
//  Yodo1MasAdMobAppOpenAdAdapter.h
//  Yodo1MasCore
//
//  Created by 周玉震 on 2022/9/26.
//

#if __has_include(<Yodo1MasCore/Yodo1MasAppOpenAdAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasAppOpenAdAdapterBase.h>
#else
#import "Yodo1MasAppOpenAdAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasAdMobAppOpenAdAdapter : Yodo1MasAppOpenAdAdapterBase

@property (nonatomic, assign) BOOL isMax;

@end

NS_ASSUME_NONNULL_END
