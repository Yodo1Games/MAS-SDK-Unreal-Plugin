//
//  Yodo1MasGoogleAdManagerAdapter.h
//  MAS
//
//  Created by ZhouYuzhen on 2022/11/23.
//

#import "Yodo1MasAdMobAdapter.h"

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasGoogleAdManagerAdapter : Yodo1MasAdMobAdapter

@end

NS_ASSUME_NONNULL_END
