//
//  APSSafeMutableDictionary.h
//  APSiOSSharedLib
//
//  Created by Amazon Publisher Services on 9/16/21.
//  Copyright © 2019 Amazon.com. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface APSSafeMutableDictionary : NSMutableDictionary
@end

NS_ASSUME_NONNULL_END
