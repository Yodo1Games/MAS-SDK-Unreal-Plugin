//
//  KSAdNativeAdStatusInfo.h
//  KSUNetworking
//
//  Created by 崔婉莹 on 2022/10/31.
//

#import <Foundation/Foundation.h>
#import "KSAdNativeStyleControl.h"

NS_ASSUME_NONNULL_BEGIN

@interface KSAdNativeAdStatusInfo : NSObject

@property (nonatomic, strong) KSAdNativeStyleControl *nativeAdStyleControl;

@end

NS_ASSUME_NONNULL_END
