//
//  KSAdNativeStyleControl.h
//  KSUNetworking
//
//  Created by 崔婉莹 on 2022/10/31.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KSAdNativeStyleControl : NSObject

///自渲染广告是否允许摇一摇
@property (nonatomic, assign) BOOL enableShake;

@end

NS_ASSUME_NONNULL_END
