//
//  KSAdExportManager.h
//  KSAdSDK
//
//  Created by 徐志军 on 2019/11/1.
//  Copyright © 2019 KuaiShou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KSAdExportManager : NSObject

+ (void)presentLogViewControllerFromViewController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
