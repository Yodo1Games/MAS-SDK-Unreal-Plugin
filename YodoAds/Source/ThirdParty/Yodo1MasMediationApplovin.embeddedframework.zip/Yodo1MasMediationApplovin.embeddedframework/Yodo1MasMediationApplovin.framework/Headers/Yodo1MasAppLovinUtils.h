//
//  Yodo1MasAppLovinUtils.h
//  Yodo1MasMediationApplovin
//
//  Created by Sunmeng on 2025/1/14.
//

#import <Foundation/Foundation.h>
#import <AppLovinSDK/AppLovinSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasAppLovinUtils : NSObject

+ (NSMutableArray *)getWaterfalls:(MAAdWaterfallInfo *)ad sessionId:(NSString*)sessionId;

@end

NS_ASSUME_NONNULL_END
