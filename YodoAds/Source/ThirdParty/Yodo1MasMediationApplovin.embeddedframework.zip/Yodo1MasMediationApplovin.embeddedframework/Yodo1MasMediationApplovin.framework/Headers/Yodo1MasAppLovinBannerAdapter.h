//
//  Yodo1MasAppLovinBannerAdapter.h
//  Yodo1MasMediationApplovin
//
//  Created by 周玉震 on 2021/11/22.
//

#if __has_include(<Yodo1MasCore/Yodo1MasBannerAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasBannerAdapterBase.h>
#else
#import "Yodo1MasBannerAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasAppLovinBannerAdapter : Yodo1MasBannerAdapterBase

@end

NS_ASSUME_NONNULL_END
