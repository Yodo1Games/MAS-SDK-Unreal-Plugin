//
//  Yodo1MasAppLovinMaxInterstitialAdapter.h
//  Yodo1MasMediationApplovin
//
//  Created by 周玉震 on 2022/5/8.
//

#if __has_include(<Yodo1MasCore/Yodo1MasInterstitialAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasInterstitialAdapterBase.h>
#else
#import "Yodo1MasInterstitialAdapterBase.h"
#endif
#import <AppLovinSDK/AppLovinSDK.h>

NS_ASSUME_NONNULL_BEGIN

@protocol Yodo1MasAppLovinMaxRecordDelegate;
@interface Yodo1MasAppLovinMaxInterstitialAdapter : Yodo1MasInterstitialAdapterBase

@property (nonatomic, weak) id<Yodo1MasAppLovinMaxRecordDelegate> recordDelegate;

@end

NS_ASSUME_NONNULL_END
