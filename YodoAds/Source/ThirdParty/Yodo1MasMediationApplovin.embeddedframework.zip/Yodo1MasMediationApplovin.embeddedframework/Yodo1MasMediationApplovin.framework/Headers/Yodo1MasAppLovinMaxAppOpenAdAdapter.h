//
//  Yodo1MasAppLovinMaxAppOpenAdAdapter.h
//  Yodo1MasCore
//
//  Created by 周玉震 on 2023/1/13.
//

#if __has_include(<Yodo1MasCore/Yodo1MasAppOpenAdAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasAppOpenAdAdapterBase.h>
#else
#import "Yodo1MasAppOpenAdAdapterBase.h"
#endif
#import <AppLovinSDK/AppLovinSDK.h>

NS_ASSUME_NONNULL_BEGIN

@protocol Yodo1MasAppLovinMaxRecordDelegate;
@interface Yodo1MasAppLovinMaxAppOpenAdAdapter : Yodo1MasAppOpenAdAdapterBase

@property (nonatomic, weak) id<Yodo1MasAppLovinMaxRecordDelegate> recordDelegate;

@end

NS_ASSUME_NONNULL_END
