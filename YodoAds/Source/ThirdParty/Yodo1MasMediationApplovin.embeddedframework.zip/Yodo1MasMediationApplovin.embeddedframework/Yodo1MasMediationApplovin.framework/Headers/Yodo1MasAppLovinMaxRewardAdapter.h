//
//  Yodo1MasAppLovinMaxRewardAdapter.h
//  Yodo1MasMediationApplovin
//
//  Created by 周玉震 on 2022/5/8.
//

#if __has_include(<Yodo1MasCore/Yodo1MasRewardAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasRewardAdapterBase.h>
#else
#import "Yodo1MasRewardAdapterBase.h"
#endif
#import <AppLovinSDK/AppLovinSDK.h>

NS_ASSUME_NONNULL_BEGIN

@protocol Yodo1MasAppLovinMaxRecordDelegate;
@interface Yodo1MasAppLovinMaxRewardAdapter : Yodo1MasRewardAdapterBase

@property (nonatomic, weak) id<Yodo1MasAppLovinMaxRecordDelegate> recordDelegate;

@end

NS_ASSUME_NONNULL_END
