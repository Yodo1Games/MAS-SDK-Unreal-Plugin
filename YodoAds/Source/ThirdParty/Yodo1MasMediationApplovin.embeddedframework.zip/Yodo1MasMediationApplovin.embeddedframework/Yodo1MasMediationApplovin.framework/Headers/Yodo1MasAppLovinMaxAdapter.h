//
//  Yodo1MasAppLovinMaxAdapter.h
//  MAS
//
//  Created by ZhouYuzhen on 2020/12/3.
//

#if __has_include(<Yodo1MasCore/Yodo1MasAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasAdapterBase.h>
#else
#import "Yodo1MasAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@class MAAd;
@protocol Yodo1MasAppLovinMaxRecordDelegate <NSObject>

@optional
- (void)onAppLovinMaxAdDisplayed:(MAAd *)ad type:(Yodo1MasAdType)type;

@end

@interface Yodo1MasAppLovinMaxAdapter : Yodo1MasAdapterBase<Yodo1MasAppLovinMaxRecordDelegate>

@end

NS_ASSUME_NONNULL_END
