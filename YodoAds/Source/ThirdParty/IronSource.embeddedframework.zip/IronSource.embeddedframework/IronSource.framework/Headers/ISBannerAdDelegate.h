//
//  ISBannerAdDelegate.h
//  IronSource
//
//  Created by Guy Lis on 27/03/2023.
//  Copyright © 2023 IronSource. All rights reserved.
//

#import "ISAdapterAdViewDelegate.h"

#ifndef ISBannerAdDelegate_h
#define ISBannerAdDelegate_h

@protocol ISBannerAdDelegate <ISAdapterAdViewDelegate>

@end

#endif /* ISBannerAdDelegate_h */
