//
//  StackProductPresentation.h
//  StackProductPresentation
//
//  Created by Stas Kochkin on 08.04.2024.
//  Copyright © 2024 Stack. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for StackProductPresentation.
FOUNDATION_EXPORT double StackProductPresentationVersionNumber;

//! Project version string for StackProductPresentation.
FOUNDATION_EXPORT const unsigned char StackProductPresentationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StackProductPresentation/PublicHeader.h>


