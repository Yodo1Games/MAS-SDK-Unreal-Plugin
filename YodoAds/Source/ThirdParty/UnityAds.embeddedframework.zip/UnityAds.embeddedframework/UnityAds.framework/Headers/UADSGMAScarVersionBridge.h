#import <Foundation/Foundation.h>
#ifdef UNITYADS_INTERNAL_SWIFT

NS_ASSUME_NONNULL_BEGIN

@interface UADSGMAScarVersionBridge : NSObject
- (NSString *) sdkVersion;
@end

NS_ASSUME_NONNULL_END
#endif
