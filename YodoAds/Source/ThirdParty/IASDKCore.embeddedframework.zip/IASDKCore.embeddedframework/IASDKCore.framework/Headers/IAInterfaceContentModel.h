//
//  IAInterfaceContentModel.h
//  IASDKCore
//
//  Created by Digital Turbine on 27/03/2017.
//  Copyright © 2022 Digital Turbine. All rights reserved.
//

#ifndef IAInterfaceContentModel_h
#define IAInterfaceContentModel_h

#import <Foundation/Foundation.h>

@protocol IAInterfaceContentModel  <NSObject, NSCopying>

@end

#endif /* IAInterfaceContentModel_h */
