//
//  IAMediationMax.h
//  IASDKCore
//
//  Created by Digital Turbine on 9/26/19.
//  Copyright © 2022 Digital Turbine. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <IASDKCore/IAMediation.h>

@interface IAMediationMax : IAMediation

@end
