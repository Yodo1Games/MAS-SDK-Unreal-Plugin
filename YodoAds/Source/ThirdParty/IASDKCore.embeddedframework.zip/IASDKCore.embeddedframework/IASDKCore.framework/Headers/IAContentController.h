//
//  IAContentController.h
//  IASDKCore
//
//  Created by Digital Turbine on 19/03/2017.
//  Copyright © 2022 Digital Turbine. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  @brief  Abstract base class.
 */
@interface IAContentController : NSObject

@end
