//
//  IAMediationDFP.h
//  IASDKCore
//
//  Created by Digital Turbine on 20/03/2017.
//  Copyright © 2022 Digital Turbine. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <IASDKCore/IAMediation.h>

@interface IAMediationDFP : IAMediation

@end
