//
//  IAMediationAdmost.h
//  IASDKCore
//
//  Created by Digital Turbine on 14/07/2021.
//  Copyright © 2022 Digital Turbine. All rights reserved.
//

#import <IASDKCore/IASDKCore.h>

NS_ASSUME_NONNULL_BEGIN

@interface IAMediationAdmost : IAMediation

@end

NS_ASSUME_NONNULL_END
