//
//  Yodo1MasGADMediationAdapterFyber.h
//  Yodo1MasMediationFyber
//
//  Created by Sunmeng on 2024/11/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasGADMediationAdapterFyber : NSObject

+ (NSString*)adapterVersion;

@end

NS_ASSUME_NONNULL_END
