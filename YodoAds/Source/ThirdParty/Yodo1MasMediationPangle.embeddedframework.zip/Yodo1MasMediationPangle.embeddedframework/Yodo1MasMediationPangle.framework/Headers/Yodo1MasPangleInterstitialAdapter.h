//
//  Yodo1MasPangleInterstitialAdapter.h
//  AFNetworking
//
//  Created by ZhouYuzhen on 2022/5/4.
//

#if __has_include(<Yodo1MasCore/Yodo1MasInterstitialAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasInterstitialAdapterBase.h>
#else
#import "Yodo1MasInterstitialAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasPangleInterstitialAdapter : Yodo1MasInterstitialAdapterBase

@end

NS_ASSUME_NONNULL_END
