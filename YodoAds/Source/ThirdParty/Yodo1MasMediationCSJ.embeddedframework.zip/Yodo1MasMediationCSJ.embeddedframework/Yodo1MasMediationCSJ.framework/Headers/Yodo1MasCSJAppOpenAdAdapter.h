//
//  Yodo1MasCSJAppOpenAdAdapter.h
//  Yodo1MasCore
//

#if __has_include(<Yodo1MasCore/Yodo1MasAppOpenAdAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasAppOpenAdAdapterBase.h>
#else
#import "Yodo1MasAppOpenAdAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasCSJAppOpenAdAdapter : Yodo1MasAppOpenAdAdapterBase

@end

NS_ASSUME_NONNULL_END
