#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "Yodo1MasPubMaticAdapter.h"

FOUNDATION_EXPORT double Yodo1MasMediationPubMaticVersionNumber;
FOUNDATION_EXPORT const unsigned char Yodo1MasMediationPubMaticVersionString[];

