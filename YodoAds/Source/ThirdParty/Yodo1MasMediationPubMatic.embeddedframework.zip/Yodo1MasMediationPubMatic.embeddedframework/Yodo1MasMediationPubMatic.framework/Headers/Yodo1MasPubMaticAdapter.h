//
//  Yodo1MasPubMaticAdapter.h
//  Yodo1MasMediationPubMatic
//
//  Created by Sunmeng on 2025/2/10.
//  Copyright © 2025 Yodo1 Games. All rights reserved.
//

#if __has_include(<Yodo1MasCore/Yodo1MasAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasAdapterBase.h>
#else
#import "Yodo1MasAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasPubMaticAdapter : Yodo1MasAdapterBase

@end

NS_ASSUME_NONNULL_END
