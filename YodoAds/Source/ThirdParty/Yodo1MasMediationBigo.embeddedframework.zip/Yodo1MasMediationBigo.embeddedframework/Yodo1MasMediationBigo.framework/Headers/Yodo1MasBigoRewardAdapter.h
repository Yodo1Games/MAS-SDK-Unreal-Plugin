//
//  Yodo1MasBigoRewardAdapter.h
//  Yodo1MasMediationBigo
//
//  Created by Sunmeng on 2024/5/6.
//

#if __has_include(<Yodo1MasCore/Yodo1MasRewardAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasRewardAdapterBase.h>
#else
#import "Yodo1MasRewardAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasBigoRewardAdapter : Yodo1MasRewardAdapterBase

@end

NS_ASSUME_NONNULL_END
