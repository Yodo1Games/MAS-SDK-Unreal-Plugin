#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "Yodo1MasBigoAdapter.h"
#import "Yodo1MasBigoAppOpenAdAdapter.h"
#import "Yodo1MasBigoBannerAdapter.h"
#import "Yodo1MasBigoInterstitialAdapter.h"
#import "Yodo1MasBigoRewardAdapter.h"

FOUNDATION_EXPORT double Yodo1MasMediationBigoVersionNumber;
FOUNDATION_EXPORT const unsigned char Yodo1MasMediationBigoVersionString[];

