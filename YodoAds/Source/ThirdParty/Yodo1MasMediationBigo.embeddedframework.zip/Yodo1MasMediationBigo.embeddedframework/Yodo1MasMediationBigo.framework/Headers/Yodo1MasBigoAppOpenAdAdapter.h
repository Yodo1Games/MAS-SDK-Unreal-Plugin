//
//  Yodo1MasBigoAppOpenAdAdapter.h
//  Yodo1MasMediationBigo
//
//  Created by Sunmeng on 2024/6/6.
//  Copyright © 2024 Yodo1 Games. All rights reserved.
//

#if __has_include(<Yodo1MasCore/Yodo1MasAppOpenAdAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasAppOpenAdAdapterBase.h>
#else
#import "Yodo1MasAppOpenAdAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasBigoAppOpenAdAdapter : Yodo1MasAppOpenAdAdapterBase

@end

NS_ASSUME_NONNULL_END
