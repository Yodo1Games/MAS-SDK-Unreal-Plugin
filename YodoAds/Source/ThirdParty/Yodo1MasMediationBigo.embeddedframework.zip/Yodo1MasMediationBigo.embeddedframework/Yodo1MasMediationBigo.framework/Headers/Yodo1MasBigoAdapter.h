//
//  Yodo1MasBigoAdapter.h
//  Yodo1MasMediationBigo
//
//  Created by Sunmeng on 2024/5/6.
//  Copyright © 2024 Yodo1 Games. All rights reserved.
//

#if __has_include(<Yodo1MasCore/Yodo1MasAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasAdapterBase.h>
#else
#import "Yodo1MasAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasBigoAdapter : Yodo1MasAdapterBase

+ (void)setBigoPrivacy;

@end

NS_ASSUME_NONNULL_END
