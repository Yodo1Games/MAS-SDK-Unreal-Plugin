//
//  Yodo1MasBigoInterstitialAdapter.h
//  Yodo1MasMediationBigo
//
//  Created by Sunmeng on 2024/5/6.
//

#if __has_include(<Yodo1MasCore/Yodo1MasInterstitialAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasInterstitialAdapterBase.h>
#else
#import "Yodo1MasInterstitialAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasBigoInterstitialAdapter : Yodo1MasInterstitialAdapterBase

@end

NS_ASSUME_NONNULL_END
