//
//  Yodo1MasYodo1AppOpenController.h
//  Yodo1MasMediationYodo1
//
//  Created by 周玉震 on 2021/11/3.
//

#import <UIKit/UIKit.h>
#if __has_include(<Yodo1MasCore/Yodo1MasPresentationBaseVC.h>)
#import <Yodo1MasCore/Yodo1MasPresentationBaseVC.h>
#else
#import "Yodo1MasPresentationBaseVC.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@protocol Yodo1MasYodo1AppOpenDelegate <NSObject>

@optional
- (void)onMasYodo1AppOpenLoaded;
- (void)onMasYodo1AppOpenLoadFailed:(NSError *)error;
- (void)onMasYodo1AppOpenOpened;
- (void)onMasYodo1AppOpenClosed;
- (void)onMasYodo1AppOpenClicked;

@end

@interface Yodo1MasYodo1AppOpenController : Yodo1MasPresentationBaseVC

@property (nonatomic, assign, readonly) BOOL isAdvertLoaded;
@property (nonatomic, weak) id<Yodo1MasYodo1AppOpenDelegate> delegate;

- (void)load;

@end

NS_ASSUME_NONNULL_END
