//
//  Yodo1MasYodo1RewardedInterstitialController.h
//  Yodo1MasMediationYodo1
//
//  Created by 周玉震 on 2021/11/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol Yodo1MasYodo1RewardedInterstitialDelegate <NSObject>

@optional
- (void)onMasYodo1RewardedInterstitialLoaded;
- (void)onMasYodo1RewardedInterstitialLoadFailed:(NSError *)error;
- (void)onMasYodo1RewardedInterstitialOpened;
- (void)onMasYodo1RewardedInterstitialClosed;
- (void)onMasYodo1RewardedInterstitialClicked;
- (void)onMasYodo1RewardedInterstitialEarned;

@end

@interface Yodo1MasYodo1RewardedInterstitialController : UIViewController

@property (nonatomic, assign, readonly) BOOL isAdvertLoaded;
@property (nonatomic, weak) id<Yodo1MasYodo1RewardedInterstitialDelegate> delegate;

- (void)load;
- (void)showInController:(UIViewController *)controller;

@end

NS_ASSUME_NONNULL_END
