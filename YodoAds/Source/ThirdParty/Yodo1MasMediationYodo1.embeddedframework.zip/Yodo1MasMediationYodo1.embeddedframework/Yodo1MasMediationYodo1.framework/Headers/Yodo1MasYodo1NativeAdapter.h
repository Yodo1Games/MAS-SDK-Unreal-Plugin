//
//  Yodo1MasYodo1NativeAdapter.h
//  Yodo1MasMediationYodo1
//
//  Created by 周玉震 on 2022/3/1.
//

#import <Foundation/Foundation.h>
#if __has_include(<Yodo1MasCore/Yodo1MasNativeAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasNativeAdapterBase.h>
#else
#import "Yodo1MasNativeAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasYodo1NativeAdapter : Yodo1MasNativeAdapterBase

@end

NS_ASSUME_NONNULL_END
