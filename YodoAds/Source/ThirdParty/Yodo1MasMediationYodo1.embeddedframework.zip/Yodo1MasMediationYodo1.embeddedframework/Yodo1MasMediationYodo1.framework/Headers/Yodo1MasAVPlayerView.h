//
//  Yodo1MasAVPlayerView.h
//  Yodo1MasMediationYodo1
//
//  Created by 周玉震 on 2021/11/3.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "Yodo1MasAVPlayer.h"

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasAVPlayerView : UIView

@property (nonatomic, strong) Yodo1MasAVPlayer *player;

@end

NS_ASSUME_NONNULL_END
