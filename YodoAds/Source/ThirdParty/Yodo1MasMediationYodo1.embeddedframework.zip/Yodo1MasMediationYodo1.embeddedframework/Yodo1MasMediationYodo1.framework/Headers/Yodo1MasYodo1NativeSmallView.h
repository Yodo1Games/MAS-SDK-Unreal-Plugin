//
//  Yodo1MasYodo1NativeSmallView.h
//  Yodo1MasMediationYodo1
//
//  Created by 周玉震 on 2022/3/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class Yodo1MasNativeAdViewBuilder;
@interface Yodo1MasYodo1NativeSmallView : UIView

+ (Yodo1MasNativeAdViewBuilder *)builder;

@end

NS_ASSUME_NONNULL_END
