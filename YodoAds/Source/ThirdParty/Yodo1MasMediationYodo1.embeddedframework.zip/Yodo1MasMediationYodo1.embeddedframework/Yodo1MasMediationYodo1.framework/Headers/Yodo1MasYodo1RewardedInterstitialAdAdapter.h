//
//  Yodo1MasYodo1RewardedInterstitialAdAdapter.h
//
//  Created by ZhouYuzhen on 2022/9/29.
//

#import <Foundation/Foundation.h>
#if __has_include(<Yodo1MasCore/Yodo1MasRewardedInterstitialAdAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasRewardedInterstitialAdAdapterBase.h>
#else
#import "Yodo1MasRewardedInterstitialAdAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasYodo1RewardedInterstitialAdAdapter : Yodo1MasRewardedInterstitialAdAdapterBase

@end

NS_ASSUME_NONNULL_END
