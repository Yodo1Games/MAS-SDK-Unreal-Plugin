//
//  Yodo1MasYodo1NativeView.h
//  AFNetworking
//
//  Created by 周玉震 on 2022/3/1.
//

#import <UIKit/UIKit.h>
#if __has_include(<Yodo1MasCore/Yodo1MasNativeAdViewBuilder.h>)
#import <Yodo1MasCore/Yodo1MasNativeAdViewBuilder.h>
#else
#import "Yodo1MasNativeAdViewBuilder.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@protocol Yodo1MasYodo1NativeDelegate <NSObject>

@optional
- (void)onMasYodo1NativeLoaded;
- (void)onMasYodo1NativeLoadFailed:(NSError *)error;
- (void)onMasYodo1NativeOpened;
- (void)onMasYodo1NativeClosed;
- (void)onMasYodo1NativeClicked;

@end

@interface Yodo1MasYodo1NativeView : UIView

@property (nonatomic, assign, readonly) BOOL isAdvertLoaded;
@property (nonatomic, weak) id<Yodo1MasYodo1NativeDelegate> delegate;

- (void)buildContentView:(UIView *)view builder:(Yodo1MasNativeAdViewBuilder *)builder;
- (void)loadAd:(NSString *)size;

@end

NS_ASSUME_NONNULL_END
