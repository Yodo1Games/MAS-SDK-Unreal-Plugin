//
//  Yodo1MasYodo1AppOpenAdAdapter.h
//
//  Created by ZhouYuzhen on 2022/9/29.
//

#import <UIKit/UIKit.h>
#if __has_include(<Yodo1MasCore/Yodo1MasAppOpenAdAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasAppOpenAdAdapterBase.h>
#else
#import "Yodo1MasAppOpenAdAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasYodo1AppOpenAdAdapter : Yodo1MasAppOpenAdAdapterBase

@end

NS_ASSUME_NONNULL_END
