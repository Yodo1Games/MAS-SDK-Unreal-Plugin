//
//  Yodo1MasMintegralInterstitialAdapter.h
//  Yodo1MasMediationMintegral
//
//  Created by Sunmeng on 2023/10/17.
//

#if __has_include(<Yodo1MasCore/Yodo1MasInterstitialAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasInterstitialAdapterBase.h>
#else
#import "Yodo1MasInterstitialAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasMintegralInterstitialAdapter : Yodo1MasInterstitialAdapterBase

@end

NS_ASSUME_NONNULL_END
