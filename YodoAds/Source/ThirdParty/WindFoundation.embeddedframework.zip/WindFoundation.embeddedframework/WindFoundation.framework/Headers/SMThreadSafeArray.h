//
//  SMThreadSafeArray.h
//  WindSDK
//
//  Created by Codi on 2020/5/19.
//  Copyright © 2020 Codi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SMThreadSafeArray<ObjectType> : NSMutableArray

@end
