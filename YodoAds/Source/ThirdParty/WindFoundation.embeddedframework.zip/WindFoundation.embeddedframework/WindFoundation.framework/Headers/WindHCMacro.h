//
//  WindHCMacro.h
//  WindHTTPCache
//
//  Created by Single on 2017/8/17.
//  Copyright © 2017年 Single. All rights reserved.
//

#import <Foundation/Foundation.h>

#if defined(__cplusplus)
#define WindHTTPCACHE_EXTERN extern "C"
#else
#define WindHTTPCACHE_EXTERN extern
#endif
