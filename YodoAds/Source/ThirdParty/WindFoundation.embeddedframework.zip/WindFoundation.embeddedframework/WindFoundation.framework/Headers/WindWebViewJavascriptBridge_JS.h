#import <Foundation/Foundation.h>

NSString * WindWebViewJavascriptBridge_js(void);
