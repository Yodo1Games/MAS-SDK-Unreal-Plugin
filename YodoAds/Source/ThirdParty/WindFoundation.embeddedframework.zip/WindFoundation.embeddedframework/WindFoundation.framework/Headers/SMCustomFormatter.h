//
//  SMCustomFormatter.h
//  WindFoundation
//
//  Created by Codi on 2022/11/2.
//

#import <Foundation/Foundation.h>
#import "SMLog.h"

@interface SMCustomFormatter : NSObject<SMLogFormatter>

@end
