//
//  YDYTTRSAEncryptorPlugin.h
//  YDYThinkingSDK
//
//  Created by wwango on 2022/1/21.
//

#import <Foundation/Foundation.h>
#import "YDYTTEncryptProtocol.h"
#import "YDYTTRSAEncryptor.h"

NS_ASSUME_NONNULL_BEGIN

@interface YDYTTRSAEncryptorPlugin : NSObject <YDYTTEncryptProtocol>

@end

NS_ASSUME_NONNULL_END
