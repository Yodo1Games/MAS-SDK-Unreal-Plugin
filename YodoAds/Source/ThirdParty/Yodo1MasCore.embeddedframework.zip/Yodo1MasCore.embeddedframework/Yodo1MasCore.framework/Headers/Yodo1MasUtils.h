//
//  Yodo1MasUtils.h
//  Yodo1MasCore
//
//  Created by Sunmeng on 2024/12/31.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasUtils : NSObject

+ (BOOL)IsLandscape;
+ (void)openURLWithYodo1Website;

@end

NS_ASSUME_NONNULL_END
