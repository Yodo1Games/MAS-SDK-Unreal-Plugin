//
//  YDYTTInstallTracker.h
//  YDYThinkingSDK
//
//  Created by wwango on 2021/10/13.
//  Copyright © 2021 thinkingdata. All rights reserved.
//

#import "YDYTTAutoTracker.h"

NS_ASSUME_NONNULL_BEGIN

@interface YDYTTInstallTracker : YDYTTAutoTracker

@end

NS_ASSUME_NONNULL_END
