//
//  Yodo1MasNetworkMediation.h
//  Yodo1MasCore
//
//  Created by ZhouYuzhen on 2020/12/7.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasNetworkMediation : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *unit_id;
@property (nonatomic, strong) NSDictionary *amazon;

@end

NS_ASSUME_NONNULL_END
