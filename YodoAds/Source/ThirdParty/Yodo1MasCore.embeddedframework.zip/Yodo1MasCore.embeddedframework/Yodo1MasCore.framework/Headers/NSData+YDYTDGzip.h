#import <Foundation/Foundation.h>

@interface NSData (YDYTDGzip)

+ (NSData *)ydy_td_gzipData:(NSData *)dataa;

@end
