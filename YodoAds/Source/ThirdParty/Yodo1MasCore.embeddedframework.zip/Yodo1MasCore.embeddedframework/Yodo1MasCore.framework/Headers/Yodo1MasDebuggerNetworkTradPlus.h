//
//  Yodo1MasDebuggerNetworkTradPlus.h
//  Yodo1MasCore
//
//  Created by Sunmeng on 2024/10/14.
//  Copyright © 2024 Yodo1 Games. All rights reserved.
//

#import "Yodo1MasDebuggerNetwork.h"

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasDebuggerNetworkTradPlus : Yodo1MasDebuggerNetwork

@end

NS_ASSUME_NONNULL_END
