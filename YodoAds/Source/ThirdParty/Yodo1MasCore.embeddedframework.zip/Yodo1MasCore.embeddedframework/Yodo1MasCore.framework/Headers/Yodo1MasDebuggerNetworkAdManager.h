//
//  Yodo1MasDebuggerAdManager.h
//  Yodo1MasCore
//
//  Created by 周玉震 on 2023/6/9.
//

#import "Yodo1MasDebuggerNetworkAdMob.h"

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasDebuggerNetworkAdManager : Yodo1MasDebuggerNetworkAdMob

@end

NS_ASSUME_NONNULL_END
