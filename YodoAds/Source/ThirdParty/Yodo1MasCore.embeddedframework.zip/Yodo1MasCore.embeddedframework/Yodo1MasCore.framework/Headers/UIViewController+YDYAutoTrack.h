#import <UIKit/UIKit.h>

@interface UIViewController (YDYAutoTrack)

- (void)ydy_td_autotrack_viewWillAppear:(BOOL)animated;

@end
