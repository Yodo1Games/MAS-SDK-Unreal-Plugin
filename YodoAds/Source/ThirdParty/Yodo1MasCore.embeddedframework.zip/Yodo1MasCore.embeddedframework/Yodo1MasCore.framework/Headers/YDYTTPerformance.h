//
//  YDYTTPerformance.h
//  YDYThinkingSDK
//
//  Created by wwango on 2021/12/23.
//  类名不能修改，外部会通过反射获取

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YDYTTPerformance : NSObject

@end


NS_ASSUME_NONNULL_END
