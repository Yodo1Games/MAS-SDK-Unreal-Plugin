//
//  Yodo1MasDebuggerNetworkBigo.h
//  Yodo1MasCore
//
//  Created by Sunmeng on 2024/5/9.
//

#import "Yodo1MasDebuggerNetwork.h"

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasDebuggerNetworkBigo : Yodo1MasDebuggerNetwork

@end

NS_ASSUME_NONNULL_END
