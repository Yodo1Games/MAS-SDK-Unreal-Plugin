//
//  YDYTTAppsFlyerSyncData.h
//  YDYThinkingSDK
//
//  Created by wwango on 2022/2/14.
//

#import "YDYTTBaseSyncData.h"

NS_ASSUME_NONNULL_BEGIN

@interface YDYTTAppsFlyerSyncData : YDYTTBaseSyncData

@end

NS_ASSUME_NONNULL_END
