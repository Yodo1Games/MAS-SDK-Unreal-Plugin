//
//  YDYTTIronSourceSyncData.h
//  YDYThinkingSDK
//
//  Created by wwango on 2022/2/16.
//

#import "YDYTTBaseSyncData.h"

NS_ASSUME_NONNULL_BEGIN

@interface YDYTTIronSourceSyncData : YDYTTBaseSyncData

@end

NS_ASSUME_NONNULL_END
