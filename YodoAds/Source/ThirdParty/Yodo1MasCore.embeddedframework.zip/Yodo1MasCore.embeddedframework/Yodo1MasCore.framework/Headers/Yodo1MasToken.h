//
//  Yodo1MasToken.h
//  Yodo1MasCore
//
//  Created by Sunmeng on 2024/7/22.
//

#ifndef Yodo1MasToken_h
#define Yodo1MasToken_h

#include <stdio.h>

double binarcy_token_verify(const char *token, double rev);

#endif /* Yodo1MasToken_h */
