//
//  YDYTTAdjustSyncData.h
//  YDYThinkingSDK
//
//  Created by 沈和平 on 2022/3/25.
//

#import "YDYTTBaseSyncData.h"

NS_ASSUME_NONNULL_BEGIN

@interface YDYTTAdjustSyncData : YDYTTBaseSyncData

@end

NS_ASSUME_NONNULL_END
