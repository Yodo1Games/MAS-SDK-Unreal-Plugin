//
//  TAQNMD5.h
//  TAHappyDNS_Mac
//
//  Created by 何昊宇 on 2018/4/25.
//  Copyright © 2018年 Qiniu Cloud Storage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TAQNMD5 : NSObject

+(NSString *)MD5:(NSString *)string;

@end
