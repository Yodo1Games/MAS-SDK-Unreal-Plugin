//
//  TDUtil.h
//  YDYThinkingSDK
//
//  Created by LiHuanan on 2020/9/8.
//  Copyright © 2020 thinkingdata. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YDYTTSDKUtil : NSObject

@end

NS_ASSUME_NONNULL_END
