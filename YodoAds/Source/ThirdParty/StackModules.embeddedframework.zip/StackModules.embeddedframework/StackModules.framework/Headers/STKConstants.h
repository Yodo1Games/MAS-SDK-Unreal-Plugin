#import <Foundation/Foundation.h>

// These constants are shared between SDK modules to ensure consistent User-Agent header usage.
FOUNDATION_EXPORT NSString *const kUserDefaultsBMUserAgentKey;
FOUNDATION_EXPORT NSString *const kHTTPHeaderUserAgentKey;
