//
//  Yodo1MasTradPlusInterstitialAdapter.h
//  Yodo1MasMediationTradPlus
//
//  Created by Sunmeng on 2024/10/12.
//  Copyright © 2024 Yodo1 Games. All rights reserved.
//

#if __has_include(<Yodo1MasCore/Yodo1MasInterstitialAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasInterstitialAdapterBase.h>
#else
#import "Yodo1MasInterstitialAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasTradPlusInterstitialAdapter : Yodo1MasInterstitialAdapterBase

@end

NS_ASSUME_NONNULL_END
