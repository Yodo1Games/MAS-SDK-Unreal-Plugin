//
//  Yodo1MasTradPlusRewardAdapter.h
//  Yodo1MasMediationTradPlus
//
//  Created by Sunmeng on 2024/10/12.
//  Copyright © 2024 Yodo1 Games. All rights reserved.
//

#if __has_include(<Yodo1MasCore/Yodo1MasRewardAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasRewardAdapterBase.h>
#else
#import "Yodo1MasRewardAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasTradPlusRewardAdapter : Yodo1MasRewardAdapterBase

@end

NS_ASSUME_NONNULL_END
