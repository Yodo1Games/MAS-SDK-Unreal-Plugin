//
//  Yodo1MasUnityAdsRewardAdapter.h
//  AFNetworking
//
//  Created by ZhouYuzhen on 2022/5/4.
//

#if __has_include(<Yodo1MasCore/Yodo1MasRewardAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasRewardAdapterBase.h>
#else
#import "Yodo1MasRewardAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasUnityAdsRewardAdapter : Yodo1MasRewardAdapterBase

@end

NS_ASSUME_NONNULL_END
