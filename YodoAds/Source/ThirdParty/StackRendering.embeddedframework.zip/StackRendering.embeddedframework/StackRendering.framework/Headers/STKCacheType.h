typedef NS_ENUM(NSInteger, STKCacheType) {
    STKCacheTypeFullLoad = 0,
    STKCacheTypeStream,
    STKCacheTypePartialLoad
} NS_SWIFT_NAME(CacheType);
