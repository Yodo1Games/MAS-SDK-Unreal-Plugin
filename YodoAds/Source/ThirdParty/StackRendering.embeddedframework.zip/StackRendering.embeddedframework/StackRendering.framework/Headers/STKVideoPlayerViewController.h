//
//  STKVideoPlayerViewController.h
//  StackVideoPlayer
//
//  Created by Ilia Lozhkin on 1/9/19.
//

#import <AVKit/AVKit.h>

@interface STKVideoPlayerViewController : AVPlayerViewController

@end
