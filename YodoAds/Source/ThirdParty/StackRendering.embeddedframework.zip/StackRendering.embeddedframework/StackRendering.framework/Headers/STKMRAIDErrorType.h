typedef NS_ENUM(NSInteger, STKMRAIDErrorType) {
    STKMRAIDErrorTypeBadContent = 101,
    STKMRAIDErrorTypeTimeouted = 201
} NS_SWIFT_NAME(MRAIDErrorType);
