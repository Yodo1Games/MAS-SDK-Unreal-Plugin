#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, STKMeasureErrorType) {
    STKMeasureErrorGeneric = 1,
    STKMeasureErrorMedia = 2
};
