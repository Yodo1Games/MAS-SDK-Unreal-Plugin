//
//  Yodo1MasIronSourceMaxInterstitialAdapter.h
//  Yodo1MasMediationIronSource
//
//  Created by 周玉震 on 2022/5/9.
//

#if __has_include(<Yodo1MasCore/Yodo1MasInterstitialAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasInterstitialAdapterBase.h>
#else
#import "Yodo1MasInterstitialAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasIronSourceMaxInterstitialAdapter : Yodo1MasInterstitialAdapterBase

@end

NS_ASSUME_NONNULL_END
