//
//  Yodo1MasIronSourceMaxRewardAdapter.h
//  Yodo1MasMediationIronSource
//
//  Created by 周玉震 on 2022/5/9.
//

#if __has_include(<Yodo1MasCore/Yodo1MasRewardAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasRewardAdapterBase.h>
#else
#import "Yodo1MasRewardAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasIronSourceMaxRewardAdapter : Yodo1MasRewardAdapterBase

@end

NS_ASSUME_NONNULL_END
