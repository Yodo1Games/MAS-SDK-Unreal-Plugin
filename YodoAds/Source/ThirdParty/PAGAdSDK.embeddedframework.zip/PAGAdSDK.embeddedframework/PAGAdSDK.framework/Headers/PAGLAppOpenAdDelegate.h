//
//  PAGLAppOpenAdDelegate.h
//  PAGAdSDK-PAGAdSDK
//
//  Created by ByteDance on 2022/4/26.
//

#import "PAGAdDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@class PAGLAppOpenAd;

@protocol PAGLAppOpenAdDelegate <PAGAdDelegate>

@end

NS_ASSUME_NONNULL_END
