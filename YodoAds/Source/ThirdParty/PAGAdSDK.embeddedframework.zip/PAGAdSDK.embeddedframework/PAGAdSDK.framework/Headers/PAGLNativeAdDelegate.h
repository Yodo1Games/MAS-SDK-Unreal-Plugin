//
//  PAGLNativeAdDelegate.h
//  PAGAdSDK
//
//  Created by Willie on 2022/3/1.
//

#import "PAGAdDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@protocol PAGLNativeAdDelegate <PAGAdDelegate>

@end

NS_ASSUME_NONNULL_END
