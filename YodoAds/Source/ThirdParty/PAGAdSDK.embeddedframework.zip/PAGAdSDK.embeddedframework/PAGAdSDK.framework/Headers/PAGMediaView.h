//
//  PAGMediaView.h
//  PAGAdSDK
//
//  Created by Willie on 2022/4/7.
//

NS_ASSUME_NONNULL_BEGIN

/// A view that wraps a fixed ad style to display an image or video
@interface PAGMediaView : UIView

@end

NS_ASSUME_NONNULL_END
