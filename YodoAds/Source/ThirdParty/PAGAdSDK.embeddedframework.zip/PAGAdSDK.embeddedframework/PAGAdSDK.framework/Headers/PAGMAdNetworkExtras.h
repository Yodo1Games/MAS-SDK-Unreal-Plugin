//
//  PAGMNetworkExtras.h
//  PAGAdSDK
//
//  Created by bytedance on 2022/11/8.
//

#import <Foundation/Foundation.h>

@protocol PAGMAdNetworkExtras <NSObject>

@end
