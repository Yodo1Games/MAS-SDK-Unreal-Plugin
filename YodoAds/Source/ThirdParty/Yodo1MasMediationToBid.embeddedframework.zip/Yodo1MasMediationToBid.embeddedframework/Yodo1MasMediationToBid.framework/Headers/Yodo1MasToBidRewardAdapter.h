//
//  Yodo1MasToBidRewardAdapter.h
//  Yodo1MasMediationToBid
//
//  Created by Sunmeng on 2024/8/30.
//  Copyright © 2024 Yodo1 Games. All rights reserved.
//

#import <Foundation/Foundation.h>

#if __has_include(<Yodo1MasCore/Yodo1MasRewardAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasRewardAdapterBase.h>
#else
#import "Yodo1MasRewardAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasToBidRewardAdapter : Yodo1MasRewardAdapterBase

@end

NS_ASSUME_NONNULL_END
