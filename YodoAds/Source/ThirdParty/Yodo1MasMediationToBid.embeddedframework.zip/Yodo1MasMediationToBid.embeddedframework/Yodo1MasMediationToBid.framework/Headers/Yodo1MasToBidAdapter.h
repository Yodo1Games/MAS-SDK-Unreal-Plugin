//
//  Yodo1MasToBidAdapter.h
//  Yodo1MasMediationToBid
//
//  Created by Sunmeng on 2024/8/30.
//  Copyright © 2024 Yodo1 Games. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WindMillSDK/WindMillSDK.h>

#if __has_include(<Yodo1MasCore/Yodo1MasAdapterBase.h>)
#import <Yodo1MasCore/Yodo1MasAdapterBase.h>
#else
#import "Yodo1MasAdapterBase.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface Yodo1MasToBidAdapter : Yodo1MasAdapterBase

@end

NS_ASSUME_NONNULL_END
