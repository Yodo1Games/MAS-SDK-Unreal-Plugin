//
//  BigoAdGender.h
//  BigoADS
//

typedef enum {
    BigoAdGenderFemale = 1,
    BigoAdGenderMale = 2
} BigoAdGender;
