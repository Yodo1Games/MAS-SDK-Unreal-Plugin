//
//  BigoAdComponentView.h
//  adsdk
//
//  Created by 李剑锋 on 2020/2/25.
//  Copyright © 2020 BIGO. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BigoAdComponentView : UIView

- (void)removeAllSubViews;

@end

NS_ASSUME_NONNULL_END
