//
//  BigoAdOptionsView.h
//  BigoADS
//
//  Created by 蔡庆敏 on 2021/7/12.
//

#import "BigoAdComponentView.h"

NS_ASSUME_NONNULL_BEGIN

@interface BigoAdOptionsView : BigoAdComponentView

@end

NS_ASSUME_NONNULL_END
