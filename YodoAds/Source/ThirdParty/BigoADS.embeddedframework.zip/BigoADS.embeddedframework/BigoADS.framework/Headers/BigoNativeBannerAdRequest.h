//
//  BigoNativeBannerAdRequest.h
//  BigoADS
//
//  Created by Chongtai H on 2021/7/20.
//

#import <Foundation/Foundation.h>
#import "BigoBannerAdRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface BigoNativeBannerAdRequest : BigoBannerAdRequest

@end

NS_ASSUME_NONNULL_END
