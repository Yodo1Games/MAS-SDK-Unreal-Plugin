//
//  BigoSplashAdRequest.h
//  BigoADS
//
//  Created by cai on 2022/5/10.
//

#import "BigoAdRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface BigoSplashAdRequest : BigoAdRequest

- (void)setServerBidPayload:(NSString *)serverBidPayload;

@end

NS_ASSUME_NONNULL_END
