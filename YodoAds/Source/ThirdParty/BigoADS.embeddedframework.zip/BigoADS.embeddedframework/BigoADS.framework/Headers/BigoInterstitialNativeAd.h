//
//  BigoInterstitialNativeAd.h
//  AFNetworking
//
//  Created by 李剑锋 on 2021/7/14.
//

#import <Foundation/Foundation.h>
#import "BigoInterstitialAd.h"

NS_ASSUME_NONNULL_BEGIN

@interface BigoInterstitialNativeAd : BigoInterstitialAd


@end

NS_ASSUME_NONNULL_END
