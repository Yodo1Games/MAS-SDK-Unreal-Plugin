//
//  BigoAdLogger.h
//  logger
//
//  Created by lijianfeng on 2020/4/27.
//

#import <Foundation/Foundation.h>
#import "BGAdLogDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface BigoAdLogger : NSObject <BGAdLogDelegate>

@end

NS_ASSUME_NONNULL_END
